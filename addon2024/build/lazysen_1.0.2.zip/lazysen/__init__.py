# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "LazySen",
    "author" : "Senshu studio", 
    "description" : "senshu lazy toybox",
    "blender" : (4, 0, 0),
    "version" : (1, 0, 2),
    "location" : "",
    "warning" : "add video feature",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Development" 
}


import bpy
import bpy.utils.previews
import os
import subprocess
from bpy.app.handlers import persistent


addon_keymaps = {}
_icons = None
class SNA_OT_Mp4Preset_Be44C(bpy.types.Operator):
    bl_idname = "sna.mp4preset_be44c"
    bl_label = "mp4preset"
    bl_description = "render setting preset"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_6D182 = set_output_render_as_mp4_h264()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Pngpreset_B2Bd9(bpy.types.Operator):
    bl_idname = "sna.pngpreset_b2bd9"
    bl_label = "pngpreset"
    bl_description = "render setting preset"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_2B4D5 = set_render_png_output()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Exrpreset_62B09(bpy.types.Operator):
    bl_idname = "sna.exrpreset_62b09"
    bl_label = "exrpreset"
    bl_description = "render setting preset"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_E8FAE = set_render_exr_output()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


from bpy import context
import datetime


def get_file_and_project_path(filepath):
    # Get the absolute path of the current .py file
    #current_file_path = os.path.abspath(__file__)
    # Get the project path by removing the current file name from the absolute path
    project_path = os.path.dirname(filepath)
    print("project Name: ", project_path)
    # Get the file name from the filepath
    file_name = os.path.basename(filepath)
    project_pathtr = ""
    folders = project_path.split(os.sep)  # Split the path into individual folder names
    print("File Name: ", folders)
    for i in range(len(folders)-1):
        if  "asset" not in folders[i] and  "Asset" not in folders[i]:
            project_pathtr = project_pathtr + folders[i] + "\\"
    # Print the file name and project path to the console
    file_name = file_name[:file_name.rfind('.')]
    print("File Name: ", file_name)
    print("Project Path: ", project_pathtr)
    return project_pathtr , file_name


def set_output_check(projectloc):
    getpath, nameblend  = get_file_and_project_path(projectloc)
    hour, minute, date, month = get_current_time()
    datetoday = str(hour) + "H" + str(minute) + "_" + str(date) + "T" + str(month)
    new_path = getpath + "check\\" + datetoday + "_" + nameblend + "_"
    bpy.context.scene.render.filepath = new_path
    print(new_path)


def open_check_folder():
    projectloc = bpy.data.filepath
    getpath, dumy = get_file_and_project_path(projectloc)
    new_path = getpath + "check\\"
    print(new_path)
    path = rf"{new_path}\\"
    if os.name == 'nt':  # Checking for Windows OS (OS name is 'nt')
        try:
            os.startfile(path)
        except Exception as e:
            print("An error occurred while trying to open the folder.")
            raise
    else:
        print("This script can only be run on Windows")


# Open Windows Explorer with the given path


def set_output_render_path(filepath):
    getpath, nameblend  = get_file_and_project_path(filepath)
    new_path = getpath + "render\\"  + nameblend + "\\"
    bpy.context.scene.render.filepath = new_path


#preset sectors


def set_render_png_output():
    # Set the render output format to PNG
    bpy.context.scene.render.image_settings.file_format = 'PNG'
    # Set the color mode to RGBA
    bpy.context.scene.render.image_settings.color_mode = 'RGBA'
    # Set the bit depth to 8-bit
    bpy.context.scene.render.image_settings.color_depth = '8'
    # Set the compression to 90%
    bpy.context.scene.render.image_settings.compression = 90


def set_render_exr_output():
    # Set the render output format to PNG
    bpy.context.scene.render.image_settings.file_format = 'OPEN_EXR'
    # Set the color mode to RGBA
    bpy.context.scene.render.image_settings.color_mode = 'RGBA'
    # Set the bit depth to 8-bit
    bpy.context.scene.render.image_settings.color_depth = '16'
    bpy.context.scene.render.image_settings.exr_codec = 'DWAB'  


def set_output_render_as_mp4_h264():
    # Set the output file format to FFMPEG
    bpy.context.scene.render.image_settings.file_format = 'FFMPEG'
    # Set the container and codec for the output file
    bpy.context.scene.render.ffmpeg.format = 'MPEG4'
    bpy.context.scene.render.ffmpeg.codec = 'H264'    


def render_viewport_animation(context):
    # get the current active camera
    camera = context.scene.camera
    # get the original render engine
    original_engine = context.scene.render.engine
    # set the render engine to Workbenchn
    #context.scene.render.engine = 'BLENDER_WORKBENCH'
    # set the render resolution to match the viewport
    #context.scene.render.resolution_x = context.region.width
    #context.scene.render.resolution_y = context.region.height
    # set the render camera to the active camera
    context.scene.render.use_multiview = False
    #context.scene.render.views_format = 'SINGLE' # remove or comment out this line
    context.scene.render.image_settings.views_format = 'INDIVIDUAL'
    context.scene.render.use_compositing = False
    context.scene.render.use_sequencer = False
    # render the animation
    #bpy.ops.render.render(animation=True, write_still=True)
    for window in context.window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces.active.region_3d.view_perspective = 'CAMERA'
                #bpy.ops.view3d.view_camera()
                bpy.ops.render.opengl(animation=True)  
    # restore the original render engine
    context.scene.render.engine = original_engine


def viewportrender():
 old_path = bpy.context.scene.render.filepath
 print(bpy.context.scene.render.filepath)
 set_output_render_as_mp4_h264()
 print(bpy.data.filepath)
 set_output_check(bpy.data.filepath)
 render_viewport_animation(bpy.context)
 set_render_png_output()
 if old_path == "" or old_path == "\\tmp\\":
  set_output_render_path(bpy.data.filepath)
 else : bpy.context.scene.render.filepath = old_path
 open_check_folder()


def get_current_time():
    now = datetime.datetime.now()
    hour = now.hour
    minute = now.minute
    date = now.day
    month = now.month
    return hour, minute, date, month


def combine_image_sequence_to_mp4():
    # Get the current scene
    scene = bpy.context.scene
    # Get frame rate and render output path from the current blend file
    frame_rate = scene.render.fps
    frame_rate_time=1/frame_rate
    render_output_path = bpy.path.abspath(scene.render.filepath)
    file_format = scene.render.image_settings.file_format.lower()
    # Extract the directory and prefix from the render output path
    render_dir, render_prefix = os.path.split(render_output_path)
    if not render_dir:
        render_dir = os.path.dirname(render_output_path)
        render_prefix = os.path.basename(render_output_path)
    # Ensure the render output directory exists
    if not os.path.exists(render_dir):
        print(f"Render directory {render_dir} does not exist.")
        return
    # Collect all files matching the prefix and format
    image_files = sorted([f for f in os.listdir(render_dir) if f.startswith(render_prefix) and f.lower().endswith(file_format)])
    # Ensure there are images to process
    if not image_files:
        print("No rendered images found.")
        return
    # Create a text file with the list of images
    file_list_path = os.path.join(render_dir, "image_list.txt")
    with open(file_list_path, 'w') as file_list:
        for image_file in image_files:
            file_list.write(f"file '{os.path.join(render_dir, image_file)}'\nduration {frame_rate_time}\n")
    # create prefix  
    projectloc = bpy.data.filepath
    getpath, blend_file_name = get_file_and_project_path(projectloc)     
    hour, minute, date, month = get_current_time()
    date_today = str(hour) + "H" + str(minute) + "_" + str(date) + "T" + str(month)
    # Create the output MP4 file path
    mp4name = str(blend_file_name)+"_"+ str(date_today) + ".mp4"
    print(f"MP4 name created: {mp4name}")
    output_mp4_path = os.path.join(render_dir, mp4name)
    print(mp4name)
    # Combine the images into an MP4 using ffmpeg with improved quality settings
    ffmpeg_command = (
        f"ffmpeg -r {frame_rate} -f concat -safe 0 -i {file_list_path}  -c:v h264_nvenc -preset slow -b:v 30M -pix_fmt yuv420p -y -minrate 10M {output_mp4_path}"
    )
    os.system(ffmpeg_command)
    print(f"MP4 file created: {output_mp4_path}")


# Example usage
#filepath = r"D:\job\makeaddon\lighting\testing.blend"
#get_file_and_project_path(filepath)


def sna_add_to_view3d_mt_editor_menus_71CE2(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.render_viewport_f2245', text='Ren check', icon_value=111, emboss=True, depress=False)
        op = layout.operator('sna.open_check_folder_ed1d6', text='', icon_value=108, emboss=True, depress=False)


class SNA_OT_Render_Viewport_F2245(bpy.types.Operator):
    bl_idname = "sna.render_viewport_f2245"
    bl_label = "render_viewport"
    bl_description = "render the viewport to mp4"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_6418D = viewportrender()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Open_Check_Folder_Ed1D6(bpy.types.Operator):
    bl_idname = "sna.open_check_folder_ed1d6"
    bl_label = "open_check_folder"
    bl_description = "render the viewport to mp4"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_7C0CD = open_check_folder()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def render_complete_handler_850D6(dummy):
    return_FD9BF =  combine_image_sequence_to_mp4()
    self.report({'INFO'}, message='All done!')


class SNA_OT_Combine_Image_Sequence_To_Mp4_7F159(bpy.types.Operator):
    bl_idname = "sna.combine_image_sequence_to_mp4_7f159"
    bl_label = " combine_image_sequence_to_mp4"
    bl_description = "combine_render_layer"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_721ED =  combine_image_sequence_to_mp4()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_PRESET_A5DF2(bpy.types.Panel):
    bl_label = 'Preset'
    bl_idname = 'SNA_PT_PRESET_A5DF2'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'render'
    bl_order = 0
    bl_options = {'HEADER_LAYOUT_EXPAND'}
    bl_parent_id = 'RENDER_PT_output'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.pngpreset_b2bd9', text='PNG', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.mp4preset_be44c', text='MP4', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.combine_image_sequence_to_mp4_7f159', text='com PNG2MP4', icon_value=692, emboss=True, depress=False)
        op = layout.operator('sna.exrpreset_62b09', text='EXR', icon_value=0, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Mp4Preset_Be44C)
    bpy.utils.register_class(SNA_OT_Pngpreset_B2Bd9)
    bpy.utils.register_class(SNA_OT_Exrpreset_62B09)
    bpy.types.VIEW3D_MT_editor_menus.append(sna_add_to_view3d_mt_editor_menus_71CE2)
    bpy.utils.register_class(SNA_OT_Render_Viewport_F2245)
    bpy.utils.register_class(SNA_OT_Open_Check_Folder_Ed1D6)
    bpy.app.handlers.render_complete.append(render_complete_handler_850D6)
    bpy.utils.register_class(SNA_OT_Combine_Image_Sequence_To_Mp4_7F159)
    bpy.utils.register_class(SNA_PT_PRESET_A5DF2)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Mp4Preset_Be44C)
    bpy.utils.unregister_class(SNA_OT_Pngpreset_B2Bd9)
    bpy.utils.unregister_class(SNA_OT_Exrpreset_62B09)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_71CE2)
    bpy.utils.unregister_class(SNA_OT_Render_Viewport_F2245)
    bpy.utils.unregister_class(SNA_OT_Open_Check_Folder_Ed1D6)
    bpy.app.handlers.render_complete.remove(render_complete_handler_850D6)
    bpy.utils.unregister_class(SNA_OT_Combine_Image_Sequence_To_Mp4_7F159)
    bpy.utils.unregister_class(SNA_PT_PRESET_A5DF2)
