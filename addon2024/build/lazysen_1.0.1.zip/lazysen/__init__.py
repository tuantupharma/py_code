# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "LazySen",
    "author" : "Senshu studio", 
    "description" : "senshu lazy toybox",
    "blender" : (4, 0, 0),
    "version" : (1, 0, 1),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Development" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None
class SNA_OT_Mp4Preset_Be44C(bpy.types.Operator):
    bl_idname = "sna.mp4preset_be44c"
    bl_label = "mp4preset"
    bl_description = "render setting preset"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_6D182 = set_output_render_as_mp4_h264()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Pngpreset_B2Bd9(bpy.types.Operator):
    bl_idname = "sna.pngpreset_b2bd9"
    bl_label = "pngpreset"
    bl_description = "render setting preset"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_2B4D5 = set_render_png_output()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Exrpreset_62B09(bpy.types.Operator):
    bl_idname = "sna.exrpreset_62b09"
    bl_label = "exrpreset"
    bl_description = "render setting preset"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_E8FAE = set_render_exr_output()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_mt_editor_menus_245CC(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.render_viewport_f2245', text='Ren check', icon_value=37, emboss=True, depress=False)


from bpy import context
import datetime


def get_file_and_project_path(filepath):
    # Get the absolute path of the current .py file
    #current_file_path = os.path.abspath(__file__)
    # Get the project path by removing the current file name from the absolute path
    project_path = os.path.dirname(filepath)
    print("project Name: ", project_path)
    # Get the file name from the filepath
    file_name = os.path.basename(filepath)
    project_pathtr = ""
    folders = project_path.split(os.sep)  # Split the path into individual folder names
    print("File Name: ", folders)
    for i in range(len(folders)-1):
        if  "asset" not in folders[i] and  "Asset" not in folders[i]:
            project_pathtr = project_pathtr + folders[i] + "\\"
    # Print the file name and project path to the console
    file_name = file_name[:file_name.rfind('.')]
    print("File Name: ", file_name)
    print("Project Path: ", project_pathtr)
    return project_pathtr , file_name


def set_output_check(projectloc):
    getpath, nameblend  = get_file_and_project_path(projectloc)
    hour, minute, date, month = get_current_time()
    datetoday = str(hour) + "H" + str(minute) + "_" + str(date) + "T" + str(month)
    new_path = getpath + "check\\" + datetoday + "_" + nameblend + "_"
    bpy.context.scene.render.filepath = new_path
    print(new_path)


def set_output_render_path(filepath):
    getpath, nameblend  = get_file_and_project_path(filepath)
    new_path = getpath + "render\\"  + nameblend + "\\"
    bpy.context.scene.render.filepath = new_path


def set_render_png_output():
    # Set the render output format to PNG
    bpy.context.scene.render.image_settings.file_format = 'PNG'
    # Set the color mode to RGBA
    bpy.context.scene.render.image_settings.color_mode = 'RGBA'
    # Set the bit depth to 8-bit
    bpy.context.scene.render.image_settings.color_depth = '8'
    # Set the compression to 90%
    bpy.context.scene.render.image_settings.compression = 90


def set_render_exr_output():
    # Set the render output format to PNG
    bpy.context.scene.render.image_settings.file_format = 'OPEN_EXR'
    # Set the color mode to RGBA
    bpy.context.scene.render.image_settings.color_mode = 'RGBA'
    # Set the bit depth to 8-bit
    bpy.context.scene.render.image_settings.color_depth = '16'
    bpy.context.scene.render.image_settings.exr_codec = 'DWAB'  


def set_output_render_as_mp4_h264():
    # Set the output file format to FFMPEG
    bpy.context.scene.render.image_settings.file_format = 'FFMPEG'
    # Set the container and codec for the output file
    bpy.context.scene.render.ffmpeg.format = 'MPEG4'
    bpy.context.scene.render.ffmpeg.codec = 'H264'    


def render_viewport_animation(context):
    # get the current active camera
    camera = context.scene.camera
    # get the original render engine
    original_engine = context.scene.render.engine
    # set the render engine to Workbenchn
    #context.scene.render.engine = 'BLENDER_WORKBENCH'
    # set the render resolution to match the viewport
    #context.scene.render.resolution_x = context.region.width
    #context.scene.render.resolution_y = context.region.height
    # set the render camera to the active camera
    context.scene.render.use_multiview = False
    #context.scene.render.views_format = 'SINGLE' # remove or comment out this line
    context.scene.render.image_settings.views_format = 'INDIVIDUAL'
    context.scene.render.use_compositing = False
    context.scene.render.use_sequencer = False
    # render the animation
    #bpy.ops.render.render(animation=True, write_still=True)
    for window in context.window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces.active.region_3d.view_perspective = 'CAMERA'
                #bpy.ops.view3d.view_camera()
                bpy.ops.render.opengl(animation=True)  
    # restore the original render engine
    context.scene.render.engine = original_engine


def viewportrender():
 old_path = bpy.context.scene.render.filepath
 print(bpy.context.scene.render.filepath)
 set_output_render_as_mp4_h264()
 print(bpy.data.filepath)
 set_output_check(bpy.data.filepath)
 render_viewport_animation(bpy.context)
 set_render_png_output()
 if old_path == "" or old_path == "\\tmp\\":
  set_output_render_path(bpy.data.filepath)
 else : bpy.context.scene.render.filepath = old_path


def get_current_time():
    now = datetime.datetime.now()
    hour = now.hour
    minute = now.minute
    date = now.day
    month = now.month
    return hour, minute, date, month


# Example usage
#filepath = r"D:\job\makeaddon\lighting\testing.blend"
#get_file_and_project_path(filepath)
class SNA_OT_Render_Viewport_F2245(bpy.types.Operator):
    bl_idname = "sna.render_viewport_f2245"
    bl_label = "render_viewport"
    bl_description = "render the viewport to mp4"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return_6418D = viewportrender()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_PRESET_CA7B5(bpy.types.Panel):
    bl_label = 'preset'
    bl_idname = 'SNA_PT_PRESET_CA7B5'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'output'
    bl_order = 0
    bl_parent_id = 'RENDER_PT_output'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.pngpreset_b2bd9', text='PNG', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.mp4preset_be44c', text='MP4', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.exrpreset_62b09', text='EXR', icon_value=0, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Mp4Preset_Be44C)
    bpy.utils.register_class(SNA_OT_Pngpreset_B2Bd9)
    bpy.utils.register_class(SNA_OT_Exrpreset_62B09)
    bpy.types.VIEW3D_MT_editor_menus.append(sna_add_to_view3d_mt_editor_menus_245CC)
    bpy.utils.register_class(SNA_OT_Render_Viewport_F2245)
    bpy.utils.register_class(SNA_PT_PRESET_CA7B5)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Mp4Preset_Be44C)
    bpy.utils.unregister_class(SNA_OT_Pngpreset_B2Bd9)
    bpy.utils.unregister_class(SNA_OT_Exrpreset_62B09)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_245CC)
    bpy.utils.unregister_class(SNA_OT_Render_Viewport_F2245)
    bpy.utils.unregister_class(SNA_PT_PRESET_CA7B5)
