'''
This is the main file that runs the MS Paint application.
'''
from paint_app import PaintApp
def main():
    paint_app = PaintApp()
    paint_app.run()
if __name__ == "__main__":
    main()